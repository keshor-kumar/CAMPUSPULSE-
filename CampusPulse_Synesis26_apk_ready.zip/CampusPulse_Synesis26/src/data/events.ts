export type CampusEvent = {
  id: string; title: string; category: string; date: string; time: string;
  venue: string; description: string; attendees: number; capacity?: number; accent: string; icon: string;
};
export const sampleEvents: CampusEvent[] = [
  { id:"e1", title:"AI & Innovation Summit", category:"Technology", date:"2026-10-22", time:"10:00 AM", venue:"Tech Block · Auditorium", description:"A day of AI demos, talks, and student-led innovation.", attendees:248, accent:"violet", icon:"✦" },
  { id:"e2", title:"Buildathon 2026", category:"Hackathon", date:"2026-10-25", time:"9:00 AM", venue:"New BMS Block", description:"Build practical solutions with a team of creative problem-solvers.", attendees:176, accent:"blue", icon:"⌘" },
  { id:"e3", title:"DesignVerse Workshop", category:"Workshop", date:"2026-10-28", time:"2:00 PM", venue:"Electronics Block - 2", description:"Learn design systems, prototyping, and product storytelling.", attendees:92, accent:"orange", icon:"◈" },
  { id:"e4", title:"Campus Cultural Night", category:"Cultural", date:"2026-11-02", time:"5:30 PM", venue:"SRM Dental College · Open Area", description:"Music, performances, and a celebration of campus creativity.", attendees:320, accent:"pink", icon:"♫" }
];