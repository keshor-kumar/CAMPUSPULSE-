import { useCallback, useEffect, useMemo, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Activity, ArrowDownRight, ArrowRight, Bell, CalendarDays, Check, ChevronDown, Compass, GraduationCap, Heart, MapPin, Menu, Search, ShieldCheck, Sparkles, Ticket, Users, X, Zap, BookOpen, MessageCircle, Plus, LockKeyhole, Mail, Eye, EyeOff } from "lucide-react";
import { sampleEvents, type CampusEvent } from "./data/events";
import { campusLocations } from "./data/locations";
import { EventCard, fmtDate } from "./components/EventCard";
import Dashboard from "./Dashboard";
import { DEMO, getDemoUser, setDemoUser } from "./lib/demo";
import { fetchEvents, fetchLocations, fetchProfile, type Profile } from "./lib/api";
import { isSupabaseConfigured, supabase } from "./lib/supabase";

type Role = "student" | "admin";

function AuthModal({ role, onClose }: { role: Role; onClose: () => void }) {
  const [mode, setMode] = useState<"login"|"register">("login");
  const [email, setEmail] = useState(role === "admin" ? "sr8658@srmist.edu.in" : "");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [message, setMessage] = useState("");
  const [busy, setBusy] = useState(false);
  const nav = useNavigate();

  async function submit(e: React.FormEvent) {
    e.preventDefault(); setMessage("");
    if (!email.trim() || !password) { setMessage("Enter your email and password."); return; }
    if (role === "admin" && mode === "register") { setMessage("Admin accounts cannot be registered publicly."); return; }
    if (mode === "register" && !name.trim()) { setMessage("Enter your full name."); return; }
    if (DEMO) {
      if (mode === "register") { setDemoUser({ role: "student", name: name.trim() }); onClose(); return; }
      setDemoUser({ role, name: role === "admin" ? "Campus Admin" : (email.split("@")[0] || "Student") }); onClose(); return;
    }
    if (!isSupabaseConfigured || !supabase) {
      setMessage("Backend not configured yet. Add your Supabase URL and publishable key to .env, then restart the server.");
      return;
    }
    setBusy(true);
    try {
      if (mode === "register") {
        const { error } = await supabase.auth.signUp({ email: email.trim(), password, options: { data: { full_name: name.trim(), role: "student" } } });
        if (error) throw error;
        setMessage("Registration submitted. Check your email if verification is enabled.");
      } else {
        const { data, error } = await supabase.auth.signInWithPassword({ email: email.trim(), password });
        if (error || !data.user) throw new Error("Invalid email or password.");
        const { data: profile, error: profileError } = await supabase.from("profiles").select("role").eq("id", data.user.id).single();
        if (profileError) throw new Error("Your profile is not configured yet. Contact the administrator.");
        if (role === "admin" && profile.role !== "admin") { await supabase.auth.signOut(); throw new Error("This account does not have administrator access."); }
        if (role === "student" && profile.role !== "student") { await supabase.auth.signOut(); throw new Error("Please use the correct sign-in option for this account."); }
        nav(role === "admin" ? "/admin" : "/student");
        onClose();
      }
    } catch (err) { setMessage(err instanceof Error ? err.message : "Something went wrong. Please try again."); }
    finally { setBusy(false); }
  }

  async function resetPassword() {
    if (!supabase || !isSupabaseConfigured) { setMessage("Configure Supabase first."); return; }
    if (!email.trim()) { setMessage("Enter your email first."); return; }
    const { error } = await supabase.auth.resetPasswordForEmail(email.trim(), { redirectTo: `${window.location.origin}/reset-password` });
    setMessage(error ? error.message : "If the account exists, a password reset email will be sent.");
  }

  return <div className="modal-backdrop" onClick={onClose}><section className="auth-modal" onClick={e=>e.stopPropagation()}>
    <button className="icon-button modal-close" onClick={onClose} aria-label="Close"><X size={19}/></button>
    <div className="brand-mark large"><Activity size={24}/></div>
    <span className="eyebrow">{role === "admin" ? "ADMIN CONSOLE" : "CAMPUS COMMUNITY"}</span>
    <h2>{mode === "register" ? "Create your account" : role === "admin" ? "Welcome back, Admin" : "Welcome back"}</h2>
    <p className="muted">{mode === "register" ? "Join your campus community in one place." : "Sign in to continue to CampusPulse."}</p>
    <form onSubmit={submit} className="auth-form">
      {mode === "register" && <label>Full name<input value={name} onChange={e=>setName(e.target.value)} placeholder="Your full name" autoComplete="name"/></label>}
      <label>Email address<div className="input-with-icon"><Mail size={17}/><input type="email" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@srmist.edu.in" autoComplete="email"/></div></label>
      <label>Password<div className="input-with-icon"><LockKeyhole size={17}/><input type={showPassword?"text":"password"} value={password} onChange={e=>setPassword(e.target.value)} placeholder="Enter your password" autoComplete={mode==="register"?"new-password":"current-password"}/><button type="button" className="field-action" onClick={()=>setShowPassword(!showPassword)}>{showPassword?<EyeOff size={16}/>:<Eye size={16}/>}</button></div></label>
      {mode === "login" && role === "student" && <button type="button" className="text-link align-right" onClick={resetPassword}>Forgot password?</button>}
      {message && <div className="form-message" role="alert">{message}</div>}
      <button className="button primary full" disabled={busy}>{busy ? "Please wait…" : mode === "register" ? "Create account" : "Sign in"} <ArrowRight size={17}/></button>
    </form>
    {role === "student" && <p className="auth-switch">{mode==="register"?"Already registered?":"New to CampusPulse?"} <button className="text-link" onClick={()=>{setMode(mode==="register"?"login":"register");setMessage("");}}>{mode==="register"?"Sign in":"Create an account"}</button></p>}
    <p className="auth-security"><ShieldCheck size={14}/> {DEMO ? "Demo mode · any password works · data stays in this browser" : <>Secure sign-in {isSupabaseConfigured ? "via Supabase" : "· backend setup required"}</>}</p>
  </section></div>;
}

function Header({ onAuth }: { onAuth: (role: Role)=>void }) {
  const [menuOpen, setMenuOpen] = useState(false);
  return <header className="site-header"><Link to="/" className="brand"><span className="brand-mark"><Activity size={20}/></span><span>Campus<span className="brand-accent">Pulse</span><small>SRM RAMAPURAM</small></span></Link>
    <nav className={menuOpen?"nav-links open":"nav-links"}><a href="#events" onClick={()=>setMenuOpen(false)}>Discover events</a><a href="#features" onClick={()=>setMenuOpen(false)}>Campus services</a><a href="#community" onClick={()=>setMenuOpen(false)}>Community</a></nav>
    <div className="header-actions"><button className="button ghost small admin-entry" onClick={()=>onAuth("admin")}>Admin login</button><button className="button primary small" onClick={()=>onAuth("student")}>Student sign in <ArrowRight size={15}/></button><button className="icon-button mobile-menu" onClick={()=>setMenuOpen(!menuOpen)} aria-label="Toggle menu">{menuOpen?<X/>:<Menu/>}</button></div>
  </header>;
}


function Landing({ onAuth, events }: { onAuth:(role:Role)=>void; events: CampusEvent[] }) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState("All events");
  const filtered = useMemo(()=>events.filter(e=>(category==="All events"||e.category===category)&&`${e.title} ${e.category} ${e.venue}`.toLowerCase().includes(query.toLowerCase())),[events,query,category]);
  return <><Header onAuth={onAuth}/><main>
    <section className="hero"><div className="hero-glow glow-a"/><div className="hero-glow glow-b"/><div className="hero-copy"><div className="hero-pill"><span className="pulse-dot"/> YOUR CAMPUS, CONNECTED <Sparkles size={14}/></div><h1>Campus life,<br/><span>in sync.</span></h1><p className="hero-description">Every event. Every opportunity. Every connection. One pulse that brings your campus community together.</p><div className="hero-actions"><button className="button primary large" onClick={()=>document.getElementById("events")?.scrollIntoView({behavior:"smooth"})}>Explore campus <ArrowRight size={18}/></button><button className="button glass large" onClick={()=>onAuth("student")}>Join the community</button></div><div className="hero-proof"><div className="avatar-stack"><span>S</span><span>C</span><span>A</span><span>+</span></div><div><strong>One connected campus</strong><small>Made for the SRM Ramapuram community</small></div></div></div>
    <div className="hero-visual"><div className="visual-topline"><span><span className="pulse-dot"/> CAMPUS LIVE</span><span>SRM · RAMAPURAM</span></div><div className="visual-orb"><div className="orb-ring ring-1"/><div className="orb-ring ring-2"/><div className="orb-ring ring-3"/><div className="orb-core"><Activity size={45}/></div><span className="orb-node node-a"><CalendarDays/></span><span className="orb-node node-b"><Users/></span><span className="orb-node node-c"><MapPin/></span><span className="orb-node node-d"><Ticket/></span></div><div className="floating-card card-event"><div className="floating-icon purple"><CalendarDays size={18}/></div><div><small>NEXT UP ON CAMPUS</small><strong>{events[0]?.title ?? "Events coming soon"}</strong><span>{events[0] ? `${fmtDate(events[0].date)} · ${events[0].venue}` : "Stay tuned"}</span></div><ArrowDownRight size={18}/></div><div className="floating-card card-community"><div className="mini-avatars"><span>A</span><span>R</span><span>K</span></div><div><strong>Community is growing</strong><small>Ideas become impact here</small></div><span className="live-dot"/></div><div className="visual-caption">YOUR CAMPUS. YOUR COMMUNITY. ONE PULSE.</div></div>
    <div className="hero-bottom"><span><ShieldCheck size={16}/> Student-first & secure</span><span><Zap size={16}/> Events made effortless</span><span><Compass size={16}/> Campus, made navigable</span></div></section>
    <section className="stats-strip"><div><strong>01</strong><span>One connected campus</span></div><div><strong>23</strong><span>Mapped campus locations</span></div><div><strong>02</strong><span>Secure account roles</span></div><div><strong>∞</strong><span>Ways to get involved</span></div></section>
    <section className="section events-section" id="events"><div className="section-heading"><div><span className="eyebrow">WHAT'S HAPPENING</span><h2>Find your next <span>big thing.</span></h2><p>Discover experiences that turn campus days into stories.</p></div><button className="text-link view-all" onClick={()=>onAuth("student")}>View all events <ArrowRight size={16}/></button></div>
      <div className="event-toolbar"><div className="search-box"><Search size={17}/><input placeholder="Search events, venues, categories..." value={query} onChange={e=>setQuery(e.target.value)}/></div><div className="filter-pills">{["All events",...Array.from(new Set(events.map(e=>e.category)))].map(c=><button key={c} className={category===c?"filter-pill active":"filter-pill"} onClick={()=>setCategory(c)}>{c}</button>)}</div></div>
      <div className="event-grid">{filtered.map(e=><EventCard key={e.id} event={e} onRegister={()=>onAuth("student")}/>)}</div>{filtered.length===0&&<div className="empty-state">No events match your search. Try another keyword or category.</div>}
    </section>
    <section className="features-section" id="features"><div className="section-heading centered"><span className="eyebrow">MORE THAN EVENTS</span><h2>Your campus, <span>all in one place.</span></h2><p>Every essential campus experience, thoughtfully connected.</p></div><div className="feature-grid">
      {[{icon:Compass,title:"Smart campus map",desc:"Explore 23 campus locations and find the building you need."},{icon:Ticket,title:"Digital QR tickets",desc:"Keep event registrations and check-in tickets in one place."},{icon:Bell,title:"Campus announcements",desc:"Stay on top of important notices and event updates."},{icon:Heart,title:"Lost & found",desc:"Help reunite people with the things they have misplaced."},{icon:GraduationCap,title:"Clubs & recruitment",desc:"Discover campus clubs and apply to opportunities."},{icon:ShieldCheck,title:"Campus safety",desc:"Find essential safety information and verified contacts."}].map(f=><article className="feature-card" key={f.title}><span className="feature-icon"><f.icon size={22}/></span><h3>{f.title}</h3><p>{f.desc}</p><ArrowRight size={17} className="feature-arrow"/></article>)}
    </div></section>
    <section className="community-section" id="community"><div className="community-copy"><span className="eyebrow">YOUR PEOPLE ARE HERE</span><h2>Find your people.<br/><span>Build something.</span></h2><p>From late-night study sessions to your next hackathon team, CampusPulse gives student ideas a place to connect.</p><button className="button primary large" onClick={()=>onAuth("student")}>Explore Community Zone <ArrowRight size={18}/></button></div><div className="community-tiles"><div className="community-tile tile-chat"><MessageCircle/><strong>Campus Chat</strong><span>Conversations that connect</span><div className="chat-lines"><i/><i/><i/></div></div><div className="community-tile tile-team"><Users/><strong>Team-Up Zone</strong><span>Build your next big idea</span><div className="team-bubbles"><b>AI</b><b>UX</b><b>DS</b><b>+</b></div></div><div className="community-tile tile-study"><BookOpen/><strong>Study Zone</strong><span>Learn better, together</span><div className="study-progress"><i/></div></div></div></section>
    <section className="cta-section"><div className="cta-glow"/><span className="eyebrow">THE CAMPUS IS YOURS</span><h2>Be part of the <span>pulse.</span></h2><p>Find your next opportunity, meet your next teammate, and make campus count.</p><button className="button white large" onClick={()=>onAuth("student")}>Get started for free <ArrowRight size={18}/></button></section>
  </main><footer className="footer"><Link to="/" className="brand footer-brand"><span className="brand-mark"><Activity size={19}/></span><span>Campus<span className="brand-accent">Pulse</span><small>SRM RAMAPURAM</small></span></Link><p>Your campus. Your community. One pulse.</p><span>Built for Synesis 26 · SRM Ramapuram</span></footer></>;
}


export default function App() {
  const [authRole,setAuthRole] = useState<Role|null>(null);
  const [session,setSession] = useState<{ userId: string; profile: Profile | null } | null>(null);
  const [checking,setChecking] = useState(true);
  const [events,setEvents] = useState<CampusEvent[]>(sampleEvents);
  const [eventsLive,setEventsLive] = useState(false);
  const [locations,setLocations] = useState(campusLocations);

  const loadEvents = useCallback(async()=>{ const r = await fetchEvents(); setEvents(r.events); setEventsLive(r.live); },[]);
  useEffect(()=>{ loadEvents(); fetchLocations().then(setLocations); },[loadEvents]);

  useEffect(()=>{
    if(DEMO){
      const sync = ()=>{ const u = getDemoUser(); setSession(u ? { userId: `demo-${u.role}`, profile: { id: `demo-${u.role}`, full_name: u.name, role: u.role } } : null); };
      sync(); setChecking(false);
      window.addEventListener("cp-demo-auth", sync);
      return ()=>window.removeEventListener("cp-demo-auth", sync);
    }
    if(!isSupabaseConfigured||!supabase){ setChecking(false); return; }
    let active = true;
    const apply = async(userId?: string)=>{
      if(!userId){ if(active) setSession(null); return; }
      const profile = await fetchProfile(userId);
      if(active) setSession({ userId, profile });
    };
    supabase.auth.getSession().then(async({data})=>{ await apply(data.session?.user.id); if(active) setChecking(false); });
    // Don't await Supabase calls inside this callback (avoids an auth deadlock) — defer them.
    const { data: sub } = supabase.auth.onAuthStateChange((_event, sess)=>{ setTimeout(()=>{ apply(sess?.user.id); },0); });
    return ()=>{ active = false; sub.subscription.unsubscribe(); };
  },[]);

  async function logout(){ if(DEMO){ setDemoUser(null); return; } if(supabase) await supabase.auth.signOut(); setSession(null); }
  if(checking) return <div className="boot-screen"><span className="brand-mark"><Activity/></span><p>Connecting to your campus…</p></div>;
  if(session?.profile) return <Dashboard role={session.profile.role} userId={session.userId} userName={session.profile.full_name} events={events} eventsLive={eventsLive} reloadEvents={loadEvents} locations={locations} onLogout={logout}/>;
  return <><Landing onAuth={setAuthRole} events={events}/>{authRole&&<AuthModal role={authRole} onClose={()=>setAuthRole(null)}/>}</>;
}
