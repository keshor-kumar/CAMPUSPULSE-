import { ArrowRight, CalendarDays, MapPin, Users } from "lucide-react";
import type { CampusEvent } from "../data/events";

export const fmtDate = (date: string) => new Date(`${date}T12:00:00`).toLocaleDateString("en-IN", { month: "short", day: "numeric" });

export function EventCard({ event, onRegister, actionLabel }: { event: CampusEvent; onRegister: () => void; actionLabel?: string }) {
  const full = event.capacity !== undefined && event.attendees >= event.capacity;
  return <article className={`event-card event-${event.accent}`}>
    <div className="event-art"><span className="event-art-label">{event.category.toUpperCase()}</span><span className="event-art-icon">{event.icon}</span><span className="art-orbit orbit-one"/><span className="art-orbit orbit-two"/><div className="art-grid"/></div>
    <div className="event-content">
      <div className="event-meta"><span><CalendarDays size={14}/>{fmtDate(event.date)} · {event.time}</span><span><Users size={14}/>{event.attendees}{event.capacity ? ` / ${event.capacity}` : ""} registered</span></div>
      <h3>{event.title}</h3><p>{event.description}</p>
      <div className="event-bottom"><span className="venue"><MapPin size={14}/>{event.venue}</span>
        <button className="round-arrow" onClick={onRegister} disabled={full} aria-label={`${actionLabel ?? "Register for"} ${event.title}`} title={full ? "Event is full" : actionLabel ?? "Register"}><ArrowRight size={18}/></button></div>
    </div>
  </article>;
}
