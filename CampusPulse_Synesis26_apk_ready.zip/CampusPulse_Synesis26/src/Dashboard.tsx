import { useCallback, useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Activity, ArrowRight, Bell, CalendarDays, ChevronDown, Compass, Megaphone, MessageCircle, Plus, QrCode, Search, ShieldCheck, Sparkles, Ticket, Users, X, BookOpen, GraduationCap, Heart, Lightbulb } from "lucide-react";
import type { CampusEvent } from "./data/events";
import type { CampusLocation } from "./data/locations";
import { EventCard } from "./components/EventCard";
import * as api from "./lib/api";
import type { Announcement, AdminStats, Proposal, Registration } from "./lib/api";

type Role = "student" | "admin";
type Props = {
  role: Role; userId: string; userName: string;
  events: CampusEvent[]; eventsLive: boolean; reloadEvents: () => void;
  locations: CampusLocation[]; onLogout: () => void;
};

type Ctx = {
  role: Role; userId: string; say: (m: string) => void; run: (fn: () => Promise<unknown>, ok?: string) => Promise<void>;
  setSection: (s: string) => void; reloadEvents: () => void; loadStats: () => void; loadProposals: () => void; loadAnnouncements: () => void;
  proposals: Proposal[]; announcements: Announcement[];
  heading: (eyebrow: string, title: string, sub: string, extra?: React.ReactNode) => React.ReactElement;
};

const errMsg = (e: unknown) => (e instanceof Error ? e.message : "Something went wrong. Please try again.");
const fmtDateTime = (iso: string) => new Date(iso).toLocaleString("en-IN", { dateStyle: "medium", timeStyle: "short", timeZone: "Asia/Kolkata" });

const MENU: Record<Role, { name: string; icon: typeof Activity }[]> = {
  student: [
    { name: "Overview", icon: Activity }, { name: "Explore Events", icon: CalendarDays }, { name: "My Tickets", icon: Ticket },
    { name: "Propose Event", icon: Lightbulb }, { name: "Campus Map", icon: Compass }, { name: "Community", icon: Users }, { name: "Announcements", icon: Bell },
  ],
  admin: [
    { name: "Overview", icon: Activity }, { name: "Events", icon: CalendarDays }, { name: "Approvals", icon: ShieldCheck },
    { name: "Check-in", icon: QrCode }, { name: "Campus Map", icon: Compass }, { name: "Announcements", icon: Megaphone },
  ],
};

export default function Dashboard({ role, userId, userName, events, eventsLive, reloadEvents, locations, onLogout }: Props) {
  const [section, setSection] = useState("Overview");
  const [notice, setNotice] = useState("");
  const [mapSearch, setMapSearch] = useState("");
  const [selected, setSelected] = useState<number | null>(null);

  const [regs, setRegs] = useState<Registration[]>([]);
  const [codes, setCodes] = useState<Record<string, string>>({});
  const [proposals, setProposals] = useState<Proposal[]>([]);
  const [announcements, setAnnouncements] = useState<Announcement[]>([]);
  const [stats, setStats] = useState<AdminStats | null>(null);

  const say = (m: string) => setNotice(m);
  const run = useCallback(async (fn: () => Promise<unknown>, ok?: string) => {
    try { await fn(); if (ok) setNotice(ok); } catch (e) { setNotice(errMsg(e)); }
  }, []);

  const loadRegs = useCallback(() => { if (role === "student") run(async () => setRegs(await api.myRegistrations())); }, [role, run]);
  const loadProposals = useCallback(() => run(async () => setProposals(await api.fetchProposals())), [run]);
  const loadAnnouncements = useCallback(() => run(async () => setAnnouncements(await api.fetchAnnouncements())), [run]);
  const loadStats = useCallback(() => { if (role === "admin") run(async () => setStats(await api.adminStats())); }, [role, run]);

  useEffect(() => { loadRegs(); loadAnnouncements(); loadStats(); if (role === "admin") loadProposals(); }, [loadRegs, loadAnnouncements, loadStats, loadProposals, role]);
  useEffect(() => { if (section === "Propose Event") loadProposals(); }, [section, loadProposals]);

  const registeredIds = new Set(regs.filter(r => r.status !== "cancelled").map(r => r.event_id));

  function register(e: CampusEvent) {
    if (!eventsLive) { say("Live registration needs the Supabase backend to be configured."); return; }
    if (role === "admin") { say("Admins manage events — sign in as a student to register."); return; }
    if (registeredIds.has(e.id)) { say("You're already registered for this event — see My Tickets."); return; }
    run(async () => { await api.registerForEvent(e.id); loadRegs(); reloadEvents(); setSection("My Tickets"); }, `Registered for ${e.title}! Your ticket is ready.`);
  }

  const visibleLocations = locations.filter(l => `${l.id} ${l.name} ${l.category}`.toLowerCase().includes(mapSearch.toLowerCase()));
  const pendingCount = proposals.filter(p => p.status === "pending").length;
  const heading = (eyebrow: string, title: string, sub: string, extra?: React.ReactNode) =>
    <div className="dash-page-heading"><div><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{sub}</p></div>{extra}</div>;

  const ctx: Ctx = { role, userId, say, run, setSection, reloadEvents, loadStats, loadProposals, loadAnnouncements, proposals, announcements, heading };

  /* ---------- sections ---------- */
  function Overview() {
    const upcoming = events.length;
    const metrics = role === "admin"
      ? [{ label: "Published events", value: stats?.published_events ?? "—", delta: "Live from database", icon: CalendarDays },
         { label: "Registrations", value: stats?.registrations ?? "—", delta: "Live from database", icon: Users },
         { label: "Pending approvals", value: stats?.pending_proposals ?? "—", delta: "Awaiting review", icon: ShieldCheck },
         { label: "Students", value: stats?.students ?? "—", delta: "Registered accounts", icon: GraduationCap }]
      : [{ label: "Upcoming events", value: upcoming, delta: "Explore what's next", icon: CalendarDays },
         { label: "My registrations", value: regs.filter(r => r.status !== "cancelled").length, delta: "Your tickets", icon: Ticket },
         { label: "Announcements", value: announcements.length, delta: "Campus updates", icon: Bell },
         { label: "Campus locations", value: locations.length, delta: "Search the blueprint", icon: Compass }];
    return <>
      {heading(role === "admin" ? "CAMPUS OPERATIONS" : "YOUR CAMPUS AT A GLANCE", `Hello, ${userName || (role === "admin" ? "Admin" : "Student")}.`, "Here's what's happening around your campus today.",
        <div className="date-chip"><CalendarDays size={16}/>{new Date().toLocaleDateString("en-IN", { weekday: "short", day: "numeric", month: "short" })}</div>)}
      <div className="metric-grid">{metrics.map((m, i) => <article className="metric-card" key={m.label}><span className={`metric-icon metric-${i}`}><m.icon size={20}/></span><span className="metric-label">{m.label}</span><strong>{m.value}</strong><small>{m.delta}</small></article>)}</div>
      <div className="dash-section-heading"><div><h2>{role === "admin" ? "Event overview" : "Recommended for you"}</h2><p>{eventsLive ? "Live events from the campus database." : "Sample events (backend not connected)."}</p></div>
        <button className="text-link" onClick={() => setSection(role === "admin" ? "Events" : "Explore Events")}>See all <ArrowRight size={15}/></button></div>
      <div className="dash-event-grid">{events.slice(0, 3).map(e => <EventCard key={e.id} event={e} onRegister={() => register(e)}/>)}</div>
      <div className="quick-actions">
        <button onClick={() => setSection("Campus Map")}><Compass/><span><strong>Explore campus map</strong><small>Find a building or facility</small></span><ArrowRight/></button>
        <button onClick={() => setSection(role === "admin" ? "Approvals" : "Propose Event")}><Users/><span><strong>{role === "admin" ? "Review proposals" : "Propose an event"}</strong><small>{role === "admin" ? "Manage submitted event ideas" : "Pitch your idea to the admins"}</small></span><ArrowRight/></button>
      </div></>;
  }

  function EventsList() {
    return <>
      {heading(role === "admin" ? "EVENT OPERATIONS" : "DISCOVER SOMETHING NEW", section, role === "admin" ? "Manage the event pipeline and published activities." : "Find your next campus experience.",
        role === "admin" ? <button className="button primary" onClick={() => setSection("Create Event")}><Plus size={17}/> Create event</button> : undefined)}
      <div className="dash-event-grid">{events.map(e => <EventCard key={e.id} event={e} actionLabel={registeredIds.has(e.id) ? "Registered:" : undefined} onRegister={() => register(e)}/>)}</div>
      {events.length === 0 && <div className="empty-state">No events published yet.</div>}</>;
  }


  function Tickets() {
    async function show(r: Registration) { await run(async () => { const c = await api.issueTicketCode(r.registration_id); setCodes(p => ({ ...p, [r.registration_id]: c })); }); }
    return <>{heading("YOUR REGISTRATIONS", "My tickets", "Show your ticket code at the venue for check-in.")}
      {regs.length === 0 ? <div className="placeholder-panel"><Ticket size={32}/><h3>No tickets yet</h3><p>Register for an event and your ticket will appear here.</p></div> :
        <div className="cp-list">{regs.map(r => <article className="cp-item" key={r.registration_id}>
          <div><span className="cp-badge">{r.status.toUpperCase()}</span><h3>{r.title}</h3><p>{fmtDateTime(r.start_at)} · {r.venue_name}</p>
            {codes[r.registration_id] && <p style={{ marginTop: 10 }}>Ticket code: <span className="cp-code">{codes[r.registration_id]}</span></p>}</div>
          <div className="cp-actions">
            {r.status === "registered" && <button className="button primary small" onClick={() => show(r)}><QrCode size={15}/> {codes[r.registration_id] ? "New code" : "Show ticket"}</button>}
            {r.status === "registered" && <button className="button ghost small" onClick={() => run(async () => { await api.cancelRegistration(r.event_id); loadRegs(); reloadEvents(); }, "Registration cancelled.")}>Cancel</button>}
          </div></article>)}</div>}</>;
  }




  function CampusMap() {
    const loc = locations.find(l => l.id === selected);
    return <>{heading("EXPLORE YOUR CAMPUS", "Campus map", "Search the SRM Ramapuram blueprint by building name or number.")}
      <div className="map-layout"><div className="map-panel"><div className="map-toolbar"><span><Compass size={17}/> SRM RAMAPURAM BLUEPRINT</span><span className="map-legend-dot"/> {locations.length} locations</div>
        <div className="map-image-wrap"><img src={`${import.meta.env.BASE_URL}images/srm-ramapuram-campus-map.png`} alt="SRM Ramapuram campus blueprint"/>{locations.map(l => <button key={l.id} title={`${l.id}. ${l.name}`} className={selected === l.id ? "map-marker active" : "map-marker"} style={{ left: `${l.x}%`, top: `${l.y}%` }} onClick={() => setSelected(l.id)}>{l.id}</button>)}</div></div>
        <div className="location-panel"><div className="search-box"><Search size={16}/><input placeholder="Search buildings..." value={mapSearch} onChange={e => setMapSearch(e.target.value)}/></div>
          <div className="location-list">{visibleLocations.map(l => <button key={l.id} className={selected === l.id ? "location-row active" : "location-row"} onClick={() => setSelected(l.id)}><span className="location-number">{l.id}</span><span><strong>{l.name}</strong><small>{l.category}</small></span><ArrowRight size={15}/></button>)}</div></div></div>
      {loc && <div className="selected-location"><span className="location-number">{loc.id}</span><div><strong>{loc.name}</strong><p>{loc.category} · Marker position is approximate.</p></div><button className="icon-button" onClick={() => setSelected(null)}><X size={17}/></button></div>}</>;
  }


  function Community() {
    const items = [[MessageCircle, "Campus Chat"], [CalendarDays, "Event Communities"], [GraduationCap, "Club Communities"], [Users, "Team-Up Zone"], [BookOpen, "Study Zone"], [Heart, "Campus Feed"]] as const;
    return <>{heading("MEET YOUR PEOPLE", "Community Zone", "Find collaborators, share ideas, and learn together.")}
      <div className="feature-grid">{items.map(([Icon, label]) => <article className="feature-card" key={label}><span className="feature-icon"><Icon size={22}/></span><h3>{label}</h3><p>Coming soon to CampusPulse.</p></article>)}</div></>;
  }

  const body =
    section === "Campus Map" ? CampusMap() :
    section === "Events" || section === "Explore Events" ? EventsList() :
    section === "Create Event" ? <CreateEvent ctx={ctx}/> :
    section === "Approvals" ? <Approvals ctx={ctx}/> :
    section === "My Tickets" ? Tickets() :
    section === "Propose Event" ? <Propose ctx={ctx}/> :
    section === "Check-in" ? <CheckIn ctx={ctx}/> :
    section === "Community" ? Community() :
    section === "Announcements" ? <Announcements ctx={ctx}/> : Overview();

  return <div className="dashboard-shell"><aside className="dash-sidebar"><Link to="/" className="brand"><span className="brand-mark"><Activity size={20}/></span><span>Campus<span className="brand-accent">Pulse</span><small>SRM RAMAPURAM</small></span></Link>
    <div className="sidebar-label">{role === "admin" ? "ADMINISTRATION" : "YOUR CAMPUS"}</div>
    <nav className="dash-nav">{MENU[role].map(m => <button key={m.name} className={section === m.name ? "dash-nav-item selected" : "dash-nav-item"} onClick={() => setSection(m.name)}><m.icon size={18}/>{m.name}{m.name === "Approvals" && pendingCount > 0 && <span className="nav-count">{pendingCount}</span>}</button>)}</nav>
    <div className="sidebar-bottom"><div className="help-card"><Sparkles size={18}/><strong>Campus, connected.</strong><p>Your next opportunity is one click away.</p></div><button className="dash-nav-item" onClick={onLogout}><ArrowRight size={18}/> Sign out</button></div></aside>
    <main className="dash-main"><header className="dash-topbar"><div className="mobile-brand"><span className="brand-mark"><Activity size={18}/></span>CampusPulse</div><div className="breadcrumb">Workspace <span>/</span> {section}</div>
      <div className="topbar-actions"><button className="icon-button" aria-label="Announcements" onClick={() => setSection("Announcements")}><Bell size={19}/></button>
        <div className="profile-chip"><span className="profile-avatar">{(userName || (role === "admin" ? "A" : "S")).charAt(0).toUpperCase()}</span><div><strong>{userName || (role === "admin" ? "Campus Admin" : "SRM Student")}</strong><small>{role === "admin" ? "Administrator" : "Student account"}</small></div><ChevronDown size={15}/></div></div></header>
      <div className="dash-content">{notice && <div className="notice-bar">{notice}<button onClick={() => setNotice("")}><X size={15}/></button></div>}{body}</div></main></div>;
}

function CreateEvent({ ctx }: { ctx: Ctx }) {
  const { role, userId, say, run, setSection, reloadEvents, loadStats, loadProposals, loadAnnouncements, proposals, announcements, heading } = ctx;
  const [f, setF] = useState({ title: "", description: "", category: "Technology", venue_name: "", start: "", end: "", capacity: 100, publish: true });
  const [busy, setBusy] = useState(false);
  const set = (k: string, v: string | number | boolean) => setF({ ...f, [k]: v });
  async function submit(ev: React.FormEvent) {
    ev.preventDefault();
    if (!f.title.trim() || !f.start || !f.end) { say("Title, start and end time are required."); return; }
    if (new Date(f.end) <= new Date(f.start)) { say("End time must be after the start time."); return; }
    setBusy(true);
    await run(async () => {
      await api.createEvent(userId, { title: f.title.trim(), description: f.description.trim(), category: f.category, venue_name: f.venue_name.trim(),
        start_at: new Date(f.start).toISOString(), end_at: new Date(f.end).toISOString(), capacity: Number(f.capacity) || 100 }, f.publish);
      reloadEvents(); loadStats(); setSection("Events");
    }, f.publish ? "Event published." : "Event saved as draft.");
    setBusy(false);
  }
  return <>{heading("EVENT OPERATIONS", "Create event", "Publish a new event for students to discover and register for.")}
    <form className="cp-form" onSubmit={submit}>
      <label>Title<input value={f.title} onChange={e => set("title", e.target.value)} required/></label>
      <label>Description<textarea rows={3} value={f.description} onChange={e => set("description", e.target.value)}/></label>
      <div className="row"><label>Category<select value={f.category} onChange={e => set("category", e.target.value)}>{["Technology", "Hackathon", "Workshop", "Cultural", "Sports", "General"].map(c => <option key={c}>{c}</option>)}</select></label>
        <label>Venue<input value={f.venue_name} onChange={e => set("venue_name", e.target.value)} placeholder="e.g. Tech Block · Auditorium"/></label></div>
      <div className="row"><label>Starts<input type="datetime-local" value={f.start} onChange={e => set("start", e.target.value)} required/></label>
        <label>Ends<input type="datetime-local" value={f.end} onChange={e => set("end", e.target.value)} required/></label></div>
      <div className="row"><label>Capacity<input type="number" min={1} value={f.capacity} onChange={e => set("capacity", Number(e.target.value))}/></label>
        <label>Visibility<select value={f.publish ? "pub" : "draft"} onChange={e => set("publish", e.target.value === "pub")}><option value="pub">Publish now</option><option value="draft">Save as draft</option></select></label></div>
      <button className="button primary" disabled={busy}>{busy ? "Saving…" : "Save event"} <ArrowRight size={16}/></button>
    </form></>;
}

function Propose({ ctx }: { ctx: Ctx }) {
  const { role, userId, say, run, setSection, reloadEvents, loadStats, loadProposals, loadAnnouncements, proposals, announcements, heading } = ctx;
  const [f, setF] = useState({ title: "", description: "", date: "", venue: "" });
  async function submit(ev: React.FormEvent) {
    ev.preventDefault();
    if (!f.title.trim()) { say("Give your event a title."); return; }
    await run(async () => {
      await api.submitProposal(userId, { title: f.title.trim(), description: f.description.trim(), proposed_date: f.date ? new Date(f.date).toISOString() : null, proposed_venue: f.venue.trim() });
      setF({ title: "", description: "", date: "", venue: "" }); loadProposals();
    }, "Proposal submitted for admin review.");
  }
  return <>{heading("MAKE IT HAPPEN", "Propose an event", "Pitch an idea. Admins review it and you'll be notified.")}
    <form className="cp-form" onSubmit={submit}>
      <label>Title<input value={f.title} onChange={e => setF({ ...f, title: e.target.value })} required/></label>
      <label>Description<textarea rows={3} value={f.description} onChange={e => setF({ ...f, description: e.target.value })}/></label>
      <div className="row"><label>Preferred date<input type="datetime-local" value={f.date} onChange={e => setF({ ...f, date: e.target.value })}/></label>
        <label>Preferred venue<input value={f.venue} onChange={e => setF({ ...f, venue: e.target.value })}/></label></div>
      <button className="button primary">Submit proposal <ArrowRight size={16}/></button>
    </form>
    {proposals.length > 0 && <><div className="dash-section-heading"><div><h2>Your proposals</h2></div></div>
      <div className="cp-list">{proposals.map(p => <article className="cp-item" key={p.id}><div><span className="cp-badge">{p.status.toUpperCase()}</span><h3>{p.title}</h3>{p.admin_comment && <p>Admin: {p.admin_comment}</p>}</div></article>)}</div></>}</>;
}

function Approvals({ ctx }: { ctx: Ctx }) {
  const { role, userId, say, run, setSection, reloadEvents, loadStats, loadProposals, loadAnnouncements, proposals, announcements, heading } = ctx;
  const [comments, setComments] = useState<Record<string, string>>({});
  const decide = (p: Proposal, d: "approved" | "rejected") =>
    run(async () => { await api.reviewProposal(p.id, d, comments[p.id] ?? ""); loadProposals(); loadStats(); reloadEvents(); }, `Proposal ${d}.`);
  return <>{heading("REVIEW QUEUE", "Event approvals", "Review submitted proposals before they reach students. Approved proposals become draft events.")}
    {proposals.length === 0 ? <div className="placeholder-panel"><ShieldCheck size={32}/><h3>Nothing to review</h3><p>Student proposals will appear here.</p></div> :
      <div className="cp-list">{proposals.map(p => <article className="cp-item" key={p.id}>
        <div><span className="cp-badge">{p.status.toUpperCase()}</span><h3>{p.title}</h3><p>{p.description || "No description."}</p>
          <p>{p.proposed_venue || "No venue"} · {p.proposed_date ? fmtDateTime(p.proposed_date) : "No date"}</p></div>
        {p.status === "pending" ? <div className="cp-actions">
          <input className="cp-comment" placeholder="Comment (optional)" value={comments[p.id] ?? ""} onChange={e => setComments({ ...comments, [p.id]: e.target.value })} style={{ font: "inherit", padding: "8px 10px", borderRadius: 10, border: "1px solid rgba(128,128,160,.35)", background: "transparent", color: "inherit" }}/>
          <button className="button primary small" onClick={() => decide(p, "approved")}>Approve</button>
          <button className="button ghost small" onClick={() => decide(p, "rejected")}>Reject</button></div> : p.admin_comment ? <p>{p.admin_comment}</p> : null}
      </article>)}</div>}</>;
}

function CheckIn({ ctx }: { ctx: Ctx }) {
  const { role, userId, say, run, setSection, reloadEvents, loadStats, loadProposals, loadAnnouncements, proposals, announcements, heading } = ctx;
  const [code, setCode] = useState("");
  async function submit(ev: React.FormEvent) {
    ev.preventDefault(); if (!code.trim()) return;
    await run(async () => { const r = await api.checkInTicket(code); say(`Checked in ${r.student_name || "student"} for ${r.event_title}.`); setCode(""); loadStats(); });
  }
  return <>{heading("EVENT DAY", "Check-in", "Enter a student's ticket code to mark them as attended.")}
    <form className="cp-form" onSubmit={submit}><label>Ticket code<input className="cp-code" value={code} onChange={e => setCode(e.target.value.toUpperCase())} placeholder="XXXXXXXXXX" autoFocus/></label>
      <button className="button primary">Check in <ArrowRight size={16}/></button></form></>;
}

function Announcements({ ctx }: { ctx: Ctx }) {
  const { role, userId, say, run, setSection, reloadEvents, loadStats, loadProposals, loadAnnouncements, proposals, announcements, heading } = ctx;
  const [f, setF] = useState({ title: "", body: "", is_important: false });
  async function submit(ev: React.FormEvent) {
    ev.preventDefault(); if (!f.title.trim() || !f.body.trim()) { say("Title and message are required."); return; }
    await run(async () => { await api.createAnnouncement(userId, { title: f.title.trim(), body: f.body.trim(), is_important: f.is_important }); setF({ title: "", body: "", is_important: false }); loadAnnouncements(); }, "Announcement published.");
  }
  return <>{heading("CAMPUS UPDATES", "Announcements", "Important notices and event updates.")}
    {role === "admin" && <form className="cp-form" onSubmit={submit} style={{ marginBottom: 20 }}>
      <label>Title<input value={f.title} onChange={e => setF({ ...f, title: e.target.value })}/></label>
      <label>Message<textarea rows={3} value={f.body} onChange={e => setF({ ...f, body: e.target.value })}/></label>
      <label style={{ display: "flex", gap: 8, alignItems: "center" }}><input type="checkbox" checked={f.is_important} onChange={e => setF({ ...f, is_important: e.target.checked })}/> Mark as important</label>
      <button className="button primary">Publish <ArrowRight size={16}/></button></form>}
    {announcements.length === 0 ? <div className="placeholder-panel"><Bell size={32}/><h3>No announcements yet</h3><p>Campus notices will appear here.</p></div> :
      <div className="cp-list">{announcements.map(a => <article className="cp-item" key={a.id}><div>{a.is_important && <span className="cp-badge">IMPORTANT</span>}<h3>{a.title}</h3><p>{a.body}</p></div><small>{a.published_at ? fmtDateTime(a.published_at) : ""}</small></article>)}</div>}</>;
}
