import { isSupabaseConfigured, supabase } from "./supabase";
import { sampleEvents, type CampusEvent } from "../data/events";
import { campusLocations, type CampusLocation } from "../data/locations";
import { DEMO, demoApi } from "./demo";

const ACCENTS: Record<string, { accent: string; icon: string }> = {
  Technology: { accent: "violet", icon: "✦" },
  Hackathon: { accent: "blue", icon: "⌘" },
  Workshop: { accent: "orange", icon: "◈" },
  Cultural: { accent: "pink", icon: "♫" },
};
const DEFAULT_ACCENT = { accent: "violet", icon: "✦" };

export type Profile = { id: string; full_name: string; role: "student" | "admin" };
export type Registration = {
  registration_id: string; event_id: string; status: string; registered_at: string;
  title: string; category: string; venue_name: string; start_at: string;
};
export type Proposal = {
  id: string; title: string; description: string; proposed_date: string | null;
  proposed_venue: string | null; status: string; admin_comment: string | null; created_at: string;
};
export type Announcement = { id: string; title: string; body: string; category: string; is_important: boolean; published_at: string | null };
export type AdminStats = { published_events: number; registrations: number; pending_proposals: number; students: number };

type PublicEventRow = {
  id: string; title: string; description: string; category: string; venue_name: string;
  start_at: string; capacity: number; registered_count: number;
};

function toCampusEvent(r: PublicEventRow): CampusEvent {
  const d = new Date(r.start_at);
  const style = ACCENTS[r.category] ?? DEFAULT_ACCENT;
  return {
    id: r.id, title: r.title, category: r.category,
    date: d.toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" }),
    time: d.toLocaleTimeString("en-IN", { hour: "numeric", minute: "2-digit", timeZone: "Asia/Kolkata" }),
    venue: r.venue_name, description: r.description,
    attendees: Number(r.registered_count), capacity: r.capacity, accent: style.accent, icon: style.icon,
  };
}

function need() {
  if (!isSupabaseConfigured || !supabase) throw new Error("Backend is not configured.");
  return supabase;
}
function fail(error: { message: string } | null): never | void {
  if (error) throw new Error(error.message);
}

/** Live events from Supabase; falls back to bundled sample events if the backend is unavailable/empty. */
export async function fetchEvents(): Promise<{ events: CampusEvent[]; live: boolean }> {
  if (DEMO) return { events: demoApi.events().map(toCampusEvent), live: true };
  if (!isSupabaseConfigured || !supabase) return { events: sampleEvents, live: false };
  const { data, error } = await supabase.rpc("list_public_events");
  if (error || !data) return { events: sampleEvents, live: false };
  return { events: (data as PublicEventRow[]).map(toCampusEvent), live: true };
}

export async function fetchLocations(): Promise<CampusLocation[]> {
  if (!isSupabaseConfigured || !supabase) return campusLocations;
  const { data, error } = await supabase.from("campus_locations").select("id,name,category,x_percent,y_percent").order("id");
  if (error || !data?.length) return campusLocations;
  return (data as { id: number; name: string; category: string; x_percent: number | string; y_percent: number | string }[]).map((l) => ({ id: l.id, name: l.name, category: l.category, x: Number(l.x_percent), y: Number(l.y_percent) }));
}

export async function fetchProfile(userId: string): Promise<Profile | null> {
  if (!supabase) return null;
  const { data } = await supabase.from("profiles").select("id,full_name,role").eq("id", userId).single();
  return (data as Profile) ?? null;
}

export async function registerForEvent(eventId: string): Promise<string> {
  if (DEMO) return demoApi.register(eventId);
  const { data, error } = await need().rpc("register_for_event", { p_event_id: eventId });
  fail(error);
  return data as string;
}
export async function cancelRegistration(eventId: string) {
  if (DEMO) return demoApi.cancel(eventId);
  fail((await need().rpc("cancel_registration", { p_event_id: eventId })).error);
}
export async function myRegistrations(): Promise<Registration[]> {
  if (DEMO) return demoApi.myRegs();
  const { data, error } = await need().rpc("my_registrations");
  fail(error);
  return (data ?? []) as Registration[];
}
export async function issueTicketCode(registrationId: string): Promise<string> {
  if (DEMO) return demoApi.issueCode(registrationId);
  const { data, error } = await need().rpc("issue_ticket_code", { p_registration_id: registrationId });
  fail(error);
  return data as string;
}
export async function checkInTicket(code: string): Promise<{ student_name: string; event_title: string }> {
  if (DEMO) return demoApi.checkIn(code);
  const { data, error } = await need().rpc("check_in_ticket", { p_code: code });
  fail(error);
  const row = Array.isArray(data) ? data[0] : data;
  return row as { student_name: string; event_title: string };
}

export async function fetchAnnouncements(): Promise<Announcement[]> {
  if (DEMO) return demoApi.announcements();
  if (!supabase) return [];
  const { data } = await supabase.from("announcements").select("id,title,body,category,is_important,published_at")
    .not("published_at", "is", null).order("published_at", { ascending: false });
  return (data ?? []) as Announcement[];
}
export async function createAnnouncement(userId: string, a: { title: string; body: string; is_important: boolean }) {
  if (DEMO) return demoApi.addAnnouncement(a);
  fail((await need().from("announcements").insert({ ...a, created_by: userId, published_at: new Date().toISOString() })).error);
}

export async function submitProposal(userId: string, p: { title: string; description: string; proposed_date: string | null; proposed_venue: string }) {
  if (DEMO) return demoApi.addProposal(p);
  fail((await need().from("event_proposals").insert({ ...p, student_id: userId })).error);
}
export async function fetchProposals(): Promise<Proposal[]> {
  if (DEMO) return demoApi.proposals();
  const { data, error } = await need().from("event_proposals")
    .select("id,title,description,proposed_date,proposed_venue,status,admin_comment,created_at").order("created_at", { ascending: false });
  fail(error);
  return (data ?? []) as Proposal[];
}
export async function reviewProposal(id: string, decision: "approved" | "rejected", comment: string) {
  if (DEMO) return demoApi.review(id, decision, comment);
  fail((await need().rpc("review_proposal", { p_id: id, p_decision: decision, p_comment: comment || null })).error);
}

export type NewEvent = { title: string; description: string; category: string; venue_name: string; start_at: string; end_at: string; capacity: number };
export async function createEvent(userId: string, e: NewEvent, publish: boolean) {
  if (DEMO) return demoApi.addEvent(e, publish);
  fail((await need().from("events").insert({ ...e, created_by: userId, status: publish ? "published" : "draft" })).error);
}
export async function adminStats(): Promise<AdminStats> {
  if (DEMO) return demoApi.stats();
  const { data, error } = await need().rpc("admin_stats");
  fail(error);
  return data as AdminStats;
}
