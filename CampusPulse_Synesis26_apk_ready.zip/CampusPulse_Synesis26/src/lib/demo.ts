// Demo mode: a browser-only stand-in for Supabase, enabled at build time with VITE_DEMO_MODE=1
// AND only when no Supabase credentials are configured. Data lives in this browser's localStorage.
import type { Announcement, AdminStats, Proposal, Registration } from "./api";

export const DEMO = import.meta.env.VITE_DEMO_MODE === "1" && !(import.meta.env.VITE_SUPABASE_URL && import.meta.env.VITE_SUPABASE_ANON_KEY);

type EventRow = { id: string; title: string; description: string; category: string; venue_name: string; start_at: string; capacity: number; registered_count: number };
type Reg = { id: string; event_id: string; status: string; created_at: string; code?: string };
type State = { events: EventRow[]; regs: Reg[]; proposals: Proposal[]; announcements: Announcement[] };

const KEY = "campuspulse-demo-v1";
const USER_KEY = "campuspulse-demo-user";
const uid = () => (crypto.randomUUID ? crypto.randomUUID() : String(Math.random()).slice(2));

function seed(): State {
  return {
    events: [
      { id: "e1", title: "AI & Innovation Summit", description: "A day of AI demos, talks, and student-led innovation.", category: "Technology", venue_name: "Tech Block · Auditorium", start_at: "2026-10-22T10:00:00+05:30", capacity: 600, registered_count: 248 },
      { id: "e2", title: "Buildathon 2026", description: "Build practical solutions with a team of creative problem-solvers.", category: "Hackathon", venue_name: "New BMS Block", start_at: "2026-10-25T09:00:00+05:30", capacity: 400, registered_count: 176 },
      { id: "e3", title: "DesignVerse Workshop", description: "Learn design systems, prototyping, and product storytelling.", category: "Workshop", venue_name: "Electronics Block - 2", start_at: "2026-10-28T14:00:00+05:30", capacity: 150, registered_count: 92 },
      { id: "e4", title: "Campus Cultural Night", description: "Music, performances, and a celebration of campus creativity.", category: "Cultural", venue_name: "SRM Dental College · Open Area", start_at: "2026-11-02T17:30:00+05:30", capacity: 1000, registered_count: 320 },
    ],
    regs: [], proposals: [],
    announcements: [{ id: "a1", title: "Welcome to CampusPulse", body: "Discover events, register in one tap, and find your way around the SRM Ramapuram campus.", category: "General", is_important: true, published_at: new Date().toISOString() }],
  };
}
function load(): State { try { const s = localStorage.getItem(KEY); if (s) return JSON.parse(s) as State; } catch { /* ignore */ } return seed(); }
function save(s: State) { try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* ignore */ } }

export type DemoUser = { role: "student" | "admin"; name: string };
export function getDemoUser(): DemoUser | null { try { const s = localStorage.getItem(USER_KEY); return s ? (JSON.parse(s) as DemoUser) : null; } catch { return null; } }
export function setDemoUser(u: DemoUser | null) {
  try { if (u) localStorage.setItem(USER_KEY, JSON.stringify(u)); else localStorage.removeItem(USER_KEY); } catch { /* ignore */ }
  window.dispatchEvent(new Event("cp-demo-auth"));
}

const mine = (s: State) => s.regs; // single local user per browser
export const demoApi = {
  events: (): EventRow[] => load().events.map(e => ({ ...e, registered_count: e.registered_count + mine(load()).filter(r => r.event_id === e.id && r.status !== "cancelled").length })),
  register(eventId: string): string {
    const s = load(); const e = s.events.find(x => x.id === eventId);
    if (!e) throw new Error("This event is not open for registration.");
    const ex = s.regs.find(r => r.event_id === eventId);
    if (ex && ex.status !== "cancelled") throw new Error("You are already registered for this event.");
    const active = e.registered_count + s.regs.filter(r => r.event_id === eventId && r.status !== "cancelled").length;
    if (active >= e.capacity) throw new Error("This event is full.");
    if (ex) { ex.status = "registered"; save(s); return ex.id; }
    const r: Reg = { id: uid(), event_id: eventId, status: "registered", created_at: new Date().toISOString() };
    s.regs.push(r); save(s); return r.id;
  },
  cancel(eventId: string) {
    const s = load(); const r = s.regs.find(x => x.event_id === eventId && x.status === "registered");
    if (!r) throw new Error("No active registration to cancel.");
    r.status = "cancelled"; save(s);
  },
  myRegs(): Registration[] {
    const s = load();
    return s.regs.map(r => { const e = s.events.find(x => x.id === r.event_id)!; return { registration_id: r.id, event_id: r.event_id, status: r.status, registered_at: r.created_at, title: e.title, category: e.category, venue_name: e.venue_name, start_at: e.start_at }; });
  },
  issueCode(regId: string): string {
    const s = load(); const r = s.regs.find(x => x.id === regId && x.status === "registered");
    if (!r) throw new Error("No active registration found.");
    r.code = Array.from(crypto.getRandomValues(new Uint8Array(5)), b => b.toString(16).padStart(2, "0")).join("").toUpperCase(); save(s); return r.code;
  },
  checkIn(code: string) {
    const s = load(); const r = s.regs.find(x => x.code === code.trim().toUpperCase());
    if (!r) throw new Error("Invalid ticket code.");
    if (r.status === "attended") throw new Error("Ticket already used.");
    if (r.status !== "registered") throw new Error("Registration is not active.");
    r.status = "attended"; save(s);
    return { student_name: "Demo student", event_title: s.events.find(e => e.id === r.event_id)!.title };
  },
  announcements: (): Announcement[] => load().announcements,
  addAnnouncement(a: { title: string; body: string; is_important: boolean }) { const s = load(); s.announcements.unshift({ id: uid(), category: "General", published_at: new Date().toISOString(), ...a }); save(s); },
  proposals: (): Proposal[] => load().proposals,
  addProposal(p: { title: string; description: string; proposed_date: string | null; proposed_venue: string }) { const s = load(); s.proposals.unshift({ id: uid(), status: "pending", admin_comment: null, created_at: new Date().toISOString(), ...p }); save(s); },
  review(id: string, decision: "approved" | "rejected", comment: string) {
    const s = load(); const p = s.proposals.find(x => x.id === id && x.status === "pending");
    if (!p) throw new Error("Proposal not found or already reviewed.");
    p.status = decision; p.admin_comment = comment || null; save(s);
  },
  addEvent(e: { title: string; description: string; category: string; venue_name: string; start_at: string; capacity: number }, publish: boolean) {
    if (!publish) return; const s = load(); s.events.push({ id: uid(), registered_count: 0, ...e }); s.events.sort((a, b) => a.start_at.localeCompare(b.start_at)); save(s);
  },
  stats(): AdminStats { const s = load(); return { published_events: s.events.length, registrations: s.events.reduce((n, e) => n + e.registered_count, 0) + s.regs.filter(r => r.status !== "cancelled").length, pending_proposals: s.proposals.filter(p => p.status === "pending").length, students: 1 }; },
};
