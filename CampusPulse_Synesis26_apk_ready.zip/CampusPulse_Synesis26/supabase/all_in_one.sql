-- CampusPulse initial schema. Review and apply to a NEW Supabase project.
-- This migration does not provision an admin password or assign admin privileges.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  student_id text unique,
  role text not null default 'student' check (role in ('student','admin')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.venues (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  building text,
  capacity integer not null default 0 check (capacity >= 0),
  facilities text[] not null default '{}',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  category text not null default 'General',
  poster_url text,
  venue_id uuid references public.venues(id),
  venue_name text not null default '',
  start_at timestamptz not null,
  end_at timestamptz not null,
  registration_deadline timestamptz,
  capacity integer not null default 100 check (capacity >= 0),
  eligibility text,
  rules text,
  fee_paise integer not null default 0 check (fee_paise >= 0),
  status text not null default 'draft' check (status in ('draft','pending','approved','rejected','published','archived')),
  created_by uuid not null references public.profiles(id),
  approved_by uuid references public.profiles(id),
  approval_comment text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (end_at > start_at)
);

create table if not exists public.event_proposals (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  description text not null default '',
  proposed_date timestamptz,
  proposed_venue text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  admin_comment text,
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.registrations (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'registered' check (status in ('registered','cancelled','attended')),
  created_at timestamptz not null default now(),
  unique(event_id, student_id)
);

create table if not exists public.tickets (
  id uuid primary key default gen_random_uuid(),
  registration_id uuid not null unique references public.registrations(id) on delete cascade,
  token_hash text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  registration_id uuid not null unique references public.registrations(id) on delete cascade,
  checked_in_by uuid not null references public.profiles(id),
  checked_in_at timestamptz not null default now()
);

create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  category text not null default 'General',
  is_important boolean not null default false,
  published_at timestamptz,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.campus_locations (
  id integer primary key,
  name text not null,
  category text not null default 'Other',
  x_percent numeric not null default 50 check (x_percent between 0 and 100),
  y_percent numeric not null default 50 check (y_percent between 0 and 100),
  details text,
  updated_at timestamptz not null default now()
);

create table if not exists public.lost_found_items (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  item_type text not null check (item_type in ('lost','found')),
  title text not null,
  description text not null default '',
  category text not null default 'Other',
  location text,
  item_date date,
  image_url text,
  status text not null default 'open' check (status in ('open','claimed','resolved','removed')),
  created_at timestamptz not null default now()
);

create table if not exists public.clubs (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  category text not null default 'General',
  description text not null default '',
  recruitment_open boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.club_applications (
  id uuid primary key default gen_random_uuid(),
  club_id uuid not null references public.clubs(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  statement text not null default '',
  status text not null default 'pending' check (status in ('pending','accepted','rejected')),
  created_at timestamptz not null default now(),
  unique(club_id, student_id)
);

create table if not exists public.venue_bookings (
  id uuid primary key default gen_random_uuid(),
  venue_id uuid not null references public.venues(id),
  event_id uuid references public.events(id) on delete set null,
  requested_by uuid not null references public.profiles(id),
  start_at timestamptz not null,
  end_at timestamptz not null,
  status text not null default 'pending' check (status in ('pending','confirmed','rejected','cancelled')),
  created_at timestamptz not null default now(),
  check (end_at > start_at)
);

create index if not exists events_status_start_idx on public.events(status, start_at);
create index if not exists registrations_student_idx on public.registrations(student_id);
create index if not exists notifications_user_created_idx on public.notifications(user_id, created_at desc);
create index if not exists lost_found_status_created_idx on public.lost_found_items(status, created_at desc);

-- Create profile rows for new signups with the STUDENT role only.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), 'student')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Role checks read trusted profile records; clients cannot update role.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

alter table public.profiles enable row level security;
alter table public.venues enable row level security;
alter table public.events enable row level security;
alter table public.event_proposals enable row level security;
alter table public.registrations enable row level security;
alter table public.tickets enable row level security;
alter table public.attendance enable row level security;
alter table public.announcements enable row level security;
alter table public.notifications enable row level security;
alter table public.campus_locations enable row level security;
alter table public.lost_found_items enable row level security;
alter table public.clubs enable row level security;
alter table public.club_applications enable row level security;
alter table public.venue_bookings enable row level security;

create policy "profiles read own or admin" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_admin());
create policy "profiles update own non-role fields" on public.profiles for update to authenticated
using (id = auth.uid() or public.is_admin())
with check ((id = auth.uid() and role = 'student') or public.is_admin());
create policy "published events readable" on public.events for select to authenticated
using (status = 'published' or public.is_admin() or created_by = auth.uid());
create policy "admin manages events" on public.events for all to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "students submit proposals" on public.event_proposals for insert to authenticated
with check (student_id = auth.uid());
create policy "proposal owner or admin reads" on public.event_proposals for select to authenticated
using (student_id = auth.uid() or public.is_admin());
create policy "admin manages proposals" on public.event_proposals for update to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "students read own registrations" on public.registrations for select to authenticated
using (student_id = auth.uid() or public.is_admin());
create policy "students create own registrations" on public.registrations for insert to authenticated
with check (student_id = auth.uid());
create policy "students cancel own registrations or admin" on public.registrations for update to authenticated
using (student_id = auth.uid() or public.is_admin())
with check ((student_id = auth.uid() and status in ('registered','cancelled','attended')) or public.is_admin());
create policy "ticket owner or admin reads" on public.tickets for select to authenticated
using (exists(select 1 from public.registrations r where r.id = registration_id and (r.student_id = auth.uid() or public.is_admin())));
create policy "attendance owner or admin reads" on public.attendance for select to authenticated
using (public.is_admin() or exists(select 1 from public.registrations r where r.id = registration_id and r.student_id = auth.uid()));
create policy "admin records attendance" on public.attendance for insert to authenticated
with check (public.is_admin());
create policy "active venues readable" on public.venues for select to authenticated
using (is_active or public.is_admin());
create policy "admin manages venues" on public.venues for all to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "published announcements readable" on public.announcements for select to authenticated
using (published_at is not null or public.is_admin());
create policy "admin manages announcements" on public.announcements for all to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "users read own notifications" on public.notifications for select to authenticated
using (user_id = auth.uid() or public.is_admin());
create policy "users update own notifications" on public.notifications for update to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "campus locations readable" on public.campus_locations for select to authenticated
using (true);
create policy "admin manages campus locations" on public.campus_locations for all to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "open lost found readable" on public.lost_found_items for select to authenticated
using (status <> 'removed' or public.is_admin());
create policy "students report lost found" on public.lost_found_items for insert to authenticated
with check (reporter_id = auth.uid());
create policy "owner or admin updates lost found" on public.lost_found_items for update to authenticated
using (reporter_id = auth.uid() or public.is_admin())
with check (reporter_id = auth.uid() or public.is_admin());
create policy "clubs readable" on public.clubs for select to authenticated using (true);
create policy "admin manages clubs" on public.clubs for all to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "students read own club applications" on public.club_applications for select to authenticated
using (student_id = auth.uid() or public.is_admin());
create policy "students apply to clubs" on public.club_applications for insert to authenticated
with check (student_id = auth.uid());
create policy "admin reviews club applications" on public.club_applications for update to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "bookings readable to owner or admin" on public.venue_bookings for select to authenticated
using (requested_by = auth.uid() or public.is_admin());
create policy "students request venue booking" on public.venue_bookings for insert to authenticated
with check (requested_by = auth.uid() and status = 'pending');
create policy "admin manages bookings" on public.venue_bookings for update to authenticated
using (public.is_admin()) with check (public.is_admin());

-- Note: production registration, ticket issuance, capacity checks, and QR check-in
-- should be implemented with transaction-safe RPC/server functions before public launch.

-- CampusPulse backend wiring: public reads, transaction-safe RPCs, seed data.
-- Run AFTER 001_initial_schema.sql. Safe to re-run.
create extension if not exists pgcrypto with schema extensions;

-- Seed rows are not owned by a user.
alter table public.events alter column created_by drop not null;
alter table public.announcements alter column created_by drop not null;

-- ---------- Public (logged-out) reads ----------
drop policy if exists "public read campus locations" on public.campus_locations;
create policy "public read campus locations" on public.campus_locations for select to anon using (true);
drop policy if exists "public read published announcements" on public.announcements;
create policy "public read published announcements" on public.announcements for select to anon
  using (published_at is not null);

-- Published events with live registration counts, readable by everyone.
create or replace function public.list_public_events()
returns table (
  id uuid, title text, description text, category text, venue_name text,
  start_at timestamptz, end_at timestamptz, capacity integer, fee_paise integer,
  poster_url text, registered_count bigint
)
language sql stable security definer set search_path = public as $$
  select e.id, e.title, e.description, e.category, e.venue_name, e.start_at, e.end_at,
         e.capacity, e.fee_paise, e.poster_url,
         (select count(*) from public.registrations r
            where r.event_id = e.id and r.status in ('registered','attended'))
  from public.events e
  where e.status = 'published'
  order by e.start_at;
$$;
grant execute on function public.list_public_events() to anon, authenticated;

-- ---------- Registration (capacity-safe) ----------
create or replace function public.register_for_event(p_event_id uuid)
returns uuid
language plpgsql security definer set search_path = public, extensions as $$
declare
  v_uid uuid := auth.uid();
  v_event public.events%rowtype;
  v_active integer;
  v_reg public.registrations%rowtype;
begin
  if v_uid is null then raise exception 'Please sign in to register.'; end if;
  select * into v_event from public.events where id = p_event_id and status = 'published' for update;
  if not found then raise exception 'This event is not open for registration.'; end if;
  if coalesce(v_event.registration_deadline, v_event.start_at) < now() then
    raise exception 'Registration for this event has closed.';
  end if;
  select * into v_reg from public.registrations where event_id = p_event_id and student_id = v_uid;
  if found and v_reg.status <> 'cancelled' then raise exception 'You are already registered for this event.'; end if;
  select count(*) into v_active from public.registrations
    where event_id = p_event_id and status in ('registered','attended');
  if v_active >= v_event.capacity then raise exception 'This event is full.'; end if;
  if found then
    update public.registrations set status = 'registered' where id = v_reg.id returning * into v_reg;
  else
    insert into public.registrations (event_id, student_id) values (p_event_id, v_uid) returning * into v_reg;
  end if;
  return v_reg.id;
end;
$$;

create or replace function public.cancel_registration(p_event_id uuid)
returns void
language plpgsql security definer set search_path = public as $$
begin
  update public.registrations set status = 'cancelled'
   where event_id = p_event_id and student_id = auth.uid() and status = 'registered';
  if not found then raise exception 'No active registration to cancel.'; end if;
end;
$$;

-- Returns the caller's registrations with event details.
create or replace function public.my_registrations()
returns table (
  registration_id uuid, event_id uuid, status text, registered_at timestamptz,
  title text, category text, venue_name text, start_at timestamptz
)
language sql stable security definer set search_path = public as $$
  select r.id, e.id, r.status, r.created_at, e.title, e.category, e.venue_name, e.start_at
  from public.registrations r join public.events e on e.id = r.event_id
  where r.student_id = auth.uid()
  order by e.start_at;
$$;

-- Issues (rotates) a ticket code for the caller's own registration. Only a hash is stored.
create or replace function public.issue_ticket_code(p_registration_id uuid)
returns text
language plpgsql security definer set search_path = public, extensions as $$
declare v_code text;
begin
  if not exists (select 1 from public.registrations
                 where id = p_registration_id and student_id = auth.uid() and status = 'registered') then
    raise exception 'No active registration found.';
  end if;
  v_code := upper(encode(gen_random_bytes(5), 'hex'));
  insert into public.tickets (registration_id, token_hash)
    values (p_registration_id, encode(digest(v_code, 'sha256'), 'hex'))
  on conflict (registration_id) do update set token_hash = excluded.token_hash;
  return v_code;
end;
$$;

-- Admin QR / code check-in.
create or replace function public.check_in_ticket(p_code text)
returns table (student_name text, event_title text)
language plpgsql security definer set search_path = public, extensions as $$
declare v_reg public.registrations%rowtype;
begin
  if not public.is_admin() then raise exception 'Administrator access required.'; end if;
  select r.* into v_reg from public.tickets t join public.registrations r on r.id = t.registration_id
   where t.token_hash = encode(digest(upper(trim(p_code)), 'sha256'), 'hex');
  if not found then raise exception 'Invalid ticket code.'; end if;
  if v_reg.status = 'attended' then raise exception 'Ticket already used.'; end if;
  if v_reg.status <> 'registered' then raise exception 'Registration is not active.'; end if;
  insert into public.attendance (registration_id, checked_in_by) values (v_reg.id, auth.uid());
  update public.registrations set status = 'attended' where id = v_reg.id;
  return query select p.full_name, e.title from public.profiles p, public.events e
    where p.id = v_reg.student_id and e.id = v_reg.event_id;
end;
$$;

-- ---------- Proposals / approvals ----------
create or replace function public.review_proposal(p_id uuid, p_decision text, p_comment text default null)
returns void
language plpgsql security definer set search_path = public as $$
declare v_p public.event_proposals%rowtype;
begin
  if not public.is_admin() then raise exception 'Administrator access required.'; end if;
  if p_decision not in ('approved','rejected') then raise exception 'Invalid decision.'; end if;
  update public.event_proposals
     set status = p_decision, admin_comment = p_comment, reviewed_by = auth.uid(), reviewed_at = now()
   where id = p_id and status = 'pending' returning * into v_p;
  if not found then raise exception 'Proposal not found or already reviewed.'; end if;
  if p_decision = 'approved' then
    insert into public.events (title, description, venue_name, start_at, end_at, status, created_by)
    values (v_p.title, v_p.description, coalesce(v_p.proposed_venue,''),
            coalesce(v_p.proposed_date, now() + interval '14 days'),
            coalesce(v_p.proposed_date, now() + interval '14 days') + interval '2 hours',
            'draft', auth.uid());
  end if;
  insert into public.notifications (user_id, title, body)
  values (v_p.student_id, 'Proposal ' || p_decision,
          'Your event proposal "' || v_p.title || '" was ' || p_decision ||
          coalesce('. Comment: ' || p_comment, '.'));
end;
$$;

-- Dashboard numbers for admins.
create or replace function public.admin_stats()
returns json
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Administrator access required.'; end if;
  return json_build_object(
    'published_events', (select count(*) from public.events where status = 'published'),
    'registrations', (select count(*) from public.registrations where status in ('registered','attended')),
    'pending_proposals', (select count(*) from public.event_proposals where status = 'pending'),
    'students', (select count(*) from public.profiles where role = 'student')
  );
end;
$$;

revoke execute on function public.register_for_event(uuid), public.cancel_registration(uuid),
  public.my_registrations(), public.issue_ticket_code(uuid), public.check_in_ticket(text),
  public.review_proposal(uuid, text, text), public.admin_stats() from public, anon;
grant execute on function public.register_for_event(uuid), public.cancel_registration(uuid),
  public.my_registrations(), public.issue_ticket_code(uuid), public.check_in_ticket(text),
  public.review_proposal(uuid, text, text), public.admin_stats() to authenticated;

-- ---------- Seed data (idempotent) ----------
insert into public.venues (name, building, capacity) values
  ('Tech Block · Auditorium','Tech Block',600),
  ('New BMS Block','New BMS Block',400),
  ('Electronics Block - 2','Electronics Block - 2',150),
  ('SRM Dental College · Open Area','SRM Dental College',1000)
on conflict (name) do nothing;

insert into public.campus_locations (id, name, category, x_percent, y_percent) values
  (1,'East Block','Academic',91.2,57.8),
  (2,'BCAS – Basement, Ground, +2','Academic',87.2,58.0),
  (3,'Placement Cell','Student Services',81.1,63.4),
  (4,'SRM Institute of Science and Technology','Academic',76.5,63.0),
  (5,'Prime SRM Multispeciality Hospital','Medical',81.2,48.3),
  (6,'Annalakshmi Catering Services','Food',75.0,49.6),
  (7,'Private Land','Other',75.1,41.0),
  (8,'SRM Institute of Science and Technology Central Library','Library',86.8,31.0),
  (9,'Boys Hostel','Hostel',77.9,29.7),
  (10,'Tech Block','Academic',66.3,39.3),
  (11,'School of Environment, Architecture and Design','Academic',63.8,29.0),
  (12,'New BMS Block','Academic',64.7,55.0),
  (13,'PG Block 1','Academic',67.6,70.0),
  (14,'PG Block 2','Academic',67.7,60.0),
  (15,'SRM Dental College','Academic',63.8,76.0),
  (16,'Electronics Block - 1','Academic',46.5,49.0),
  (17,'Electronics Block - 2','Academic',55.0,49.0),
  (18,'PG Civil & Mechanical Block','Academic',39.2,77.0),
  (19,'SRM Easwari Engineering College Main Block','Academic',28.0,44.0),
  (20,'Omi Vinayaga Hostel','Hostel',15.3,60.0),
  (21,'Chellammal Ladies Hostel','Hostel',16.0,70.0),
  (22,'Swasakthi Ladies Hostel','Hostel',27.0,71.0),
  (23,'Research Block','Academic',15.2,52.5)
on conflict (id) do nothing;

insert into public.events (title, description, category, venue_name, start_at, end_at, capacity, status)
select v.title, v.description, v.category, v.venue_name, v.start_at::timestamptz, v.end_at::timestamptz, v.capacity, 'published'
from (values
  ('AI & Innovation Summit','A day of AI demos, talks, and student-led innovation.','Technology','Tech Block · Auditorium','2026-10-22 10:00+05:30','2026-10-22 17:00+05:30',600),
  ('Buildathon 2026','Build practical solutions with a team of creative problem-solvers.','Hackathon','New BMS Block','2026-10-25 09:00+05:30','2026-10-26 09:00+05:30',400),
  ('DesignVerse Workshop','Learn design systems, prototyping, and product storytelling.','Workshop','Electronics Block - 2','2026-10-28 14:00+05:30','2026-10-28 17:00+05:30',150),
  ('Campus Cultural Night','Music, performances, and a celebration of campus creativity.','Cultural','SRM Dental College · Open Area','2026-11-02 17:30+05:30','2026-11-02 21:30+05:30',1000)
) as v(title, description, category, venue_name, start_at, end_at, capacity)
where not exists (select 1 from public.events e where e.title = v.title);

insert into public.announcements (title, body, category, is_important, published_at)
select 'Welcome to CampusPulse', 'Discover events, register in one tap, and find your way around the SRM Ramapuram campus.', 'General', true, now()
where not exists (select 1 from public.announcements where title = 'Welcome to CampusPulse');
