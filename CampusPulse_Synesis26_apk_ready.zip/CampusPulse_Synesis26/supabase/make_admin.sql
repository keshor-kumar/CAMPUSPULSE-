-- Run in the Supabase SQL Editor AFTER creating/confirming the admin's account (Auth > Users).
update public.profiles p
set role = 'admin'
from auth.users u
where u.id = p.id
  and lower(u.email) = 'sr8658@srmist.edu.in'
  and u.email_confirmed_at is not null;
