-- CampusPulse backend wiring: public reads, transaction-safe RPCs, seed data.
-- Run AFTER 001_initial_schema.sql. Safe to re-run.
create extension if not exists pgcrypto with schema extensions;

-- Seed rows are not owned by a user.
alter table public.events alter column created_by drop not null;
alter table public.announcements alter column created_by drop not null;

-- ---------- Public (logged-out) reads ----------
drop policy if exists "public read campus locations" on public.campus_locations;
create policy "public read campus locations" on public.campus_locations for select to anon using (true);
drop policy if exists "public read published announcements" on public.announcements;
create policy "public read published announcements" on public.announcements for select to anon
  using (published_at is not null);

-- Published events with live registration counts, readable by everyone.
create or replace function public.list_public_events()
returns table (
  id uuid, title text, description text, category text, venue_name text,
  start_at timestamptz, end_at timestamptz, capacity integer, fee_paise integer,
  poster_url text, registered_count bigint
)
language sql stable security definer set search_path = public as $$
  select e.id, e.title, e.description, e.category, e.venue_name, e.start_at, e.end_at,
         e.capacity, e.fee_paise, e.poster_url,
         (select count(*) from public.registrations r
            where r.event_id = e.id and r.status in ('registered','attended'))
  from public.events e
  where e.status = 'published'
  order by e.start_at;
$$;
grant execute on function public.list_public_events() to anon, authenticated;

-- ---------- Registration (capacity-safe) ----------
create or replace function public.register_for_event(p_event_id uuid)
returns uuid
language plpgsql security definer set search_path = public, extensions as $$
declare
  v_uid uuid := auth.uid();
  v_event public.events%rowtype;
  v_active integer;
  v_reg public.registrations%rowtype;
begin
  if v_uid is null then raise exception 'Please sign in to register.'; end if;
  select * into v_event from public.events where id = p_event_id and status = 'published' for update;
  if not found then raise exception 'This event is not open for registration.'; end if;
  if coalesce(v_event.registration_deadline, v_event.start_at) < now() then
    raise exception 'Registration for this event has closed.';
  end if;
  select * into v_reg from public.registrations where event_id = p_event_id and student_id = v_uid;
  if found and v_reg.status <> 'cancelled' then raise exception 'You are already registered for this event.'; end if;
  select count(*) into v_active from public.registrations
    where event_id = p_event_id and status in ('registered','attended');
  if v_active >= v_event.capacity then raise exception 'This event is full.'; end if;
  if found then
    update public.registrations set status = 'registered' where id = v_reg.id returning * into v_reg;
  else
    insert into public.registrations (event_id, student_id) values (p_event_id, v_uid) returning * into v_reg;
  end if;
  return v_reg.id;
end;
$$;

create or replace function public.cancel_registration(p_event_id uuid)
returns void
language plpgsql security definer set search_path = public as $$
begin
  update public.registrations set status = 'cancelled'
   where event_id = p_event_id and student_id = auth.uid() and status = 'registered';
  if not found then raise exception 'No active registration to cancel.'; end if;
end;
$$;

-- Returns the caller's registrations with event details.
create or replace function public.my_registrations()
returns table (
  registration_id uuid, event_id uuid, status text, registered_at timestamptz,
  title text, category text, venue_name text, start_at timestamptz
)
language sql stable security definer set search_path = public as $$
  select r.id, e.id, r.status, r.created_at, e.title, e.category, e.venue_name, e.start_at
  from public.registrations r join public.events e on e.id = r.event_id
  where r.student_id = auth.uid()
  order by e.start_at;
$$;

-- Issues (rotates) a ticket code for the caller's own registration. Only a hash is stored.
create or replace function public.issue_ticket_code(p_registration_id uuid)
returns text
language plpgsql security definer set search_path = public, extensions as $$
declare v_code text;
begin
  if not exists (select 1 from public.registrations
                 where id = p_registration_id and student_id = auth.uid() and status = 'registered') then
    raise exception 'No active registration found.';
  end if;
  v_code := upper(encode(gen_random_bytes(5), 'hex'));
  insert into public.tickets (registration_id, token_hash)
    values (p_registration_id, encode(digest(v_code, 'sha256'), 'hex'))
  on conflict (registration_id) do update set token_hash = excluded.token_hash;
  return v_code;
end;
$$;

-- Admin QR / code check-in.
create or replace function public.check_in_ticket(p_code text)
returns table (student_name text, event_title text)
language plpgsql security definer set search_path = public, extensions as $$
declare v_reg public.registrations%rowtype;
begin
  if not public.is_admin() then raise exception 'Administrator access required.'; end if;
  select r.* into v_reg from public.tickets t join public.registrations r on r.id = t.registration_id
   where t.token_hash = encode(digest(upper(trim(p_code)), 'sha256'), 'hex');
  if not found then raise exception 'Invalid ticket code.'; end if;
  if v_reg.status = 'attended' then raise exception 'Ticket already used.'; end if;
  if v_reg.status <> 'registered' then raise exception 'Registration is not active.'; end if;
  insert into public.attendance (registration_id, checked_in_by) values (v_reg.id, auth.uid());
  update public.registrations set status = 'attended' where id = v_reg.id;
  return query select p.full_name, e.title from public.profiles p, public.events e
    where p.id = v_reg.student_id and e.id = v_reg.event_id;
end;
$$;

-- ---------- Proposals / approvals ----------
create or replace function public.review_proposal(p_id uuid, p_decision text, p_comment text default null)
returns void
language plpgsql security definer set search_path = public as $$
declare v_p public.event_proposals%rowtype;
begin
  if not public.is_admin() then raise exception 'Administrator access required.'; end if;
  if p_decision not in ('approved','rejected') then raise exception 'Invalid decision.'; end if;
  update public.event_proposals
     set status = p_decision, admin_comment = p_comment, reviewed_by = auth.uid(), reviewed_at = now()
   where id = p_id and status = 'pending' returning * into v_p;
  if not found then raise exception 'Proposal not found or already reviewed.'; end if;
  if p_decision = 'approved' then
    insert into public.events (title, description, venue_name, start_at, end_at, status, created_by)
    values (v_p.title, v_p.description, coalesce(v_p.proposed_venue,''),
            coalesce(v_p.proposed_date, now() + interval '14 days'),
            coalesce(v_p.proposed_date, now() + interval '14 days') + interval '2 hours',
            'draft', auth.uid());
  end if;
  insert into public.notifications (user_id, title, body)
  values (v_p.student_id, 'Proposal ' || p_decision,
          'Your event proposal "' || v_p.title || '" was ' || p_decision ||
          coalesce('. Comment: ' || p_comment, '.'));
end;
$$;

-- Dashboard numbers for admins.
create or replace function public.admin_stats()
returns json
language plpgsql stable security definer set search_path = public as $$
begin
  if not public.is_admin() then raise exception 'Administrator access required.'; end if;
  return json_build_object(
    'published_events', (select count(*) from public.events where status = 'published'),
    'registrations', (select count(*) from public.registrations where status in ('registered','attended')),
    'pending_proposals', (select count(*) from public.event_proposals where status = 'pending'),
    'students', (select count(*) from public.profiles where role = 'student')
  );
end;
$$;

revoke execute on function public.register_for_event(uuid), public.cancel_registration(uuid),
  public.my_registrations(), public.issue_ticket_code(uuid), public.check_in_ticket(text),
  public.review_proposal(uuid, text, text), public.admin_stats() from public, anon;
grant execute on function public.register_for_event(uuid), public.cancel_registration(uuid),
  public.my_registrations(), public.issue_ticket_code(uuid), public.check_in_ticket(text),
  public.review_proposal(uuid, text, text), public.admin_stats() to authenticated;

-- ---------- Seed data (idempotent) ----------
insert into public.venues (name, building, capacity) values
  ('Tech Block · Auditorium','Tech Block',600),
  ('New BMS Block','New BMS Block',400),
  ('Electronics Block - 2','Electronics Block - 2',150),
  ('SRM Dental College · Open Area','SRM Dental College',1000)
on conflict (name) do nothing;

insert into public.campus_locations (id, name, category, x_percent, y_percent) values
  (1,'East Block','Academic',91.2,57.8),
  (2,'BCAS – Basement, Ground, +2','Academic',87.2,58.0),
  (3,'Placement Cell','Student Services',81.1,63.4),
  (4,'SRM Institute of Science and Technology','Academic',76.5,63.0),
  (5,'Prime SRM Multispeciality Hospital','Medical',81.2,48.3),
  (6,'Annalakshmi Catering Services','Food',75.0,49.6),
  (7,'Private Land','Other',75.1,41.0),
  (8,'SRM Institute of Science and Technology Central Library','Library',86.8,31.0),
  (9,'Boys Hostel','Hostel',77.9,29.7),
  (10,'Tech Block','Academic',66.3,39.3),
  (11,'School of Environment, Architecture and Design','Academic',63.8,29.0),
  (12,'New BMS Block','Academic',64.7,55.0),
  (13,'PG Block 1','Academic',67.6,70.0),
  (14,'PG Block 2','Academic',67.7,60.0),
  (15,'SRM Dental College','Academic',63.8,76.0),
  (16,'Electronics Block - 1','Academic',46.5,49.0),
  (17,'Electronics Block - 2','Academic',55.0,49.0),
  (18,'PG Civil & Mechanical Block','Academic',39.2,77.0),
  (19,'SRM Easwari Engineering College Main Block','Academic',28.0,44.0),
  (20,'Omi Vinayaga Hostel','Hostel',15.3,60.0),
  (21,'Chellammal Ladies Hostel','Hostel',16.0,70.0),
  (22,'Swasakthi Ladies Hostel','Hostel',27.0,71.0),
  (23,'Research Block','Academic',15.2,52.5)
on conflict (id) do nothing;

insert into public.events (title, description, category, venue_name, start_at, end_at, capacity, status)
select v.title, v.description, v.category, v.venue_name, v.start_at::timestamptz, v.end_at::timestamptz, v.capacity, 'published'
from (values
  ('AI & Innovation Summit','A day of AI demos, talks, and student-led innovation.','Technology','Tech Block · Auditorium','2026-10-22 10:00+05:30','2026-10-22 17:00+05:30',600),
  ('Buildathon 2026','Build practical solutions with a team of creative problem-solvers.','Hackathon','New BMS Block','2026-10-25 09:00+05:30','2026-10-26 09:00+05:30',400),
  ('DesignVerse Workshop','Learn design systems, prototyping, and product storytelling.','Workshop','Electronics Block - 2','2026-10-28 14:00+05:30','2026-10-28 17:00+05:30',150),
  ('Campus Cultural Night','Music, performances, and a celebration of campus creativity.','Cultural','SRM Dental College · Open Area','2026-11-02 17:30+05:30','2026-11-02 21:30+05:30',1000)
) as v(title, description, category, venue_name, start_at, end_at, capacity)
where not exists (select 1 from public.events e where e.title = v.title);

insert into public.announcements (title, body, category, is_important, published_at)
select 'Welcome to CampusPulse', 'Discover events, register in one tap, and find your way around the SRM Ramapuram campus.', 'General', true, now()
where not exists (select 1 from public.announcements where title = 'Welcome to CampusPulse');
