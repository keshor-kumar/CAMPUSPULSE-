-- CampusPulse initial schema. Review and apply to a NEW Supabase project.
-- This migration does not provision an admin password or assign admin privileges.
create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  student_id text unique,
  role text not null default 'student' check (role in ('student','admin')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.venues (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  building text,
  capacity integer not null default 0 check (capacity >= 0),
  facilities text[] not null default '{}',
  is_active boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.events (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  description text not null default '',
  category text not null default 'General',
  poster_url text,
  venue_id uuid references public.venues(id),
  venue_name text not null default '',
  start_at timestamptz not null,
  end_at timestamptz not null,
  registration_deadline timestamptz,
  capacity integer not null default 100 check (capacity >= 0),
  eligibility text,
  rules text,
  fee_paise integer not null default 0 check (fee_paise >= 0),
  status text not null default 'draft' check (status in ('draft','pending','approved','rejected','published','archived')),
  created_by uuid not null references public.profiles(id),
  approved_by uuid references public.profiles(id),
  approval_comment text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (end_at > start_at)
);

create table if not exists public.event_proposals (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  description text not null default '',
  proposed_date timestamptz,
  proposed_venue text,
  status text not null default 'pending' check (status in ('pending','approved','rejected')),
  admin_comment text,
  reviewed_by uuid references public.profiles(id),
  reviewed_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.registrations (
  id uuid primary key default gen_random_uuid(),
  event_id uuid not null references public.events(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  status text not null default 'registered' check (status in ('registered','cancelled','attended')),
  created_at timestamptz not null default now(),
  unique(event_id, student_id)
);

create table if not exists public.tickets (
  id uuid primary key default gen_random_uuid(),
  registration_id uuid not null unique references public.registrations(id) on delete cascade,
  token_hash text not null unique,
  created_at timestamptz not null default now()
);

create table if not exists public.attendance (
  id uuid primary key default gen_random_uuid(),
  registration_id uuid not null unique references public.registrations(id) on delete cascade,
  checked_in_by uuid not null references public.profiles(id),
  checked_in_at timestamptz not null default now()
);

create table if not exists public.announcements (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  body text not null,
  category text not null default 'General',
  is_important boolean not null default false,
  published_at timestamptz,
  created_by uuid not null references public.profiles(id),
  created_at timestamptz not null default now()
);

create table if not exists public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null,
  body text not null,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.campus_locations (
  id integer primary key,
  name text not null,
  category text not null default 'Other',
  x_percent numeric not null default 50 check (x_percent between 0 and 100),
  y_percent numeric not null default 50 check (y_percent between 0 and 100),
  details text,
  updated_at timestamptz not null default now()
);

create table if not exists public.lost_found_items (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid not null references public.profiles(id) on delete cascade,
  item_type text not null check (item_type in ('lost','found')),
  title text not null,
  description text not null default '',
  category text not null default 'Other',
  location text,
  item_date date,
  image_url text,
  status text not null default 'open' check (status in ('open','claimed','resolved','removed')),
  created_at timestamptz not null default now()
);

create table if not exists public.clubs (
  id uuid primary key default gen_random_uuid(),
  name text not null unique,
  category text not null default 'General',
  description text not null default '',
  recruitment_open boolean not null default false,
  created_at timestamptz not null default now()
);

create table if not exists public.club_applications (
  id uuid primary key default gen_random_uuid(),
  club_id uuid not null references public.clubs(id) on delete cascade,
  student_id uuid not null references public.profiles(id) on delete cascade,
  statement text not null default '',
  status text not null default 'pending' check (status in ('pending','accepted','rejected')),
  created_at timestamptz not null default now(),
  unique(club_id, student_id)
);

create table if not exists public.venue_bookings (
  id uuid primary key default gen_random_uuid(),
  venue_id uuid not null references public.venues(id),
  event_id uuid references public.events(id) on delete set null,
  requested_by uuid not null references public.profiles(id),
  start_at timestamptz not null,
  end_at timestamptz not null,
  status text not null default 'pending' check (status in ('pending','confirmed','rejected','cancelled')),
  created_at timestamptz not null default now(),
  check (end_at > start_at)
);

create index if not exists events_status_start_idx on public.events(status, start_at);
create index if not exists registrations_student_idx on public.registrations(student_id);
create index if not exists notifications_user_created_idx on public.notifications(user_id, created_at desc);
create index if not exists lost_found_status_created_idx on public.lost_found_items(status, created_at desc);

-- Create profile rows for new signups with the STUDENT role only.
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  insert into public.profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name',''), 'student')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

-- Role checks read trusted profile records; clients cannot update role.
create or replace function public.is_admin()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists(select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

alter table public.profiles enable row level security;
alter table public.venues enable row level security;
alter table public.events enable row level security;
alter table public.event_proposals enable row level security;
alter table public.registrations enable row level security;
alter table public.tickets enable row level security;
alter table public.attendance enable row level security;
alter table public.announcements enable row level security;
alter table public.notifications enable row level security;
alter table public.campus_locations enable row level security;
alter table public.lost_found_items enable row level security;
alter table public.clubs enable row level security;
alter table public.club_applications enable row level security;
alter table public.venue_bookings enable row level security;

create policy "profiles read own or admin" on public.profiles for select to authenticated
using (id = auth.uid() or public.is_admin());
create policy "profiles update own non-role fields" on public.profiles for update to authenticated
using (id = auth.uid() or public.is_admin())
with check ((id = auth.uid() and role = 'student') or public.is_admin());
create policy "published events readable" on public.events for select to authenticated
using (status = 'published' or public.is_admin() or created_by = auth.uid());
create policy "admin manages events" on public.events for all to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "students submit proposals" on public.event_proposals for insert to authenticated
with check (student_id = auth.uid());
create policy "proposal owner or admin reads" on public.event_proposals for select to authenticated
using (student_id = auth.uid() or public.is_admin());
create policy "admin manages proposals" on public.event_proposals for update to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "students read own registrations" on public.registrations for select to authenticated
using (student_id = auth.uid() or public.is_admin());
create policy "students create own registrations" on public.registrations for insert to authenticated
with check (student_id = auth.uid());
create policy "students cancel own registrations or admin" on public.registrations for update to authenticated
using (student_id = auth.uid() or public.is_admin())
with check ((student_id = auth.uid() and status in ('registered','cancelled','attended')) or public.is_admin());
create policy "ticket owner or admin reads" on public.tickets for select to authenticated
using (exists(select 1 from public.registrations r where r.id = registration_id and (r.student_id = auth.uid() or public.is_admin())));
create policy "attendance owner or admin reads" on public.attendance for select to authenticated
using (public.is_admin() or exists(select 1 from public.registrations r where r.id = registration_id and r.student_id = auth.uid()));
create policy "admin records attendance" on public.attendance for insert to authenticated
with check (public.is_admin());
create policy "active venues readable" on public.venues for select to authenticated
using (is_active or public.is_admin());
create policy "admin manages venues" on public.venues for all to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "published announcements readable" on public.announcements for select to authenticated
using (published_at is not null or public.is_admin());
create policy "admin manages announcements" on public.announcements for all to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "users read own notifications" on public.notifications for select to authenticated
using (user_id = auth.uid() or public.is_admin());
create policy "users update own notifications" on public.notifications for update to authenticated
using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "campus locations readable" on public.campus_locations for select to authenticated
using (true);
create policy "admin manages campus locations" on public.campus_locations for all to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "open lost found readable" on public.lost_found_items for select to authenticated
using (status <> 'removed' or public.is_admin());
create policy "students report lost found" on public.lost_found_items for insert to authenticated
with check (reporter_id = auth.uid());
create policy "owner or admin updates lost found" on public.lost_found_items for update to authenticated
using (reporter_id = auth.uid() or public.is_admin())
with check (reporter_id = auth.uid() or public.is_admin());
create policy "clubs readable" on public.clubs for select to authenticated using (true);
create policy "admin manages clubs" on public.clubs for all to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "students read own club applications" on public.club_applications for select to authenticated
using (student_id = auth.uid() or public.is_admin());
create policy "students apply to clubs" on public.club_applications for insert to authenticated
with check (student_id = auth.uid());
create policy "admin reviews club applications" on public.club_applications for update to authenticated
using (public.is_admin()) with check (public.is_admin());
create policy "bookings readable to owner or admin" on public.venue_bookings for select to authenticated
using (requested_by = auth.uid() or public.is_admin());
create policy "students request venue booking" on public.venue_bookings for insert to authenticated
with check (requested_by = auth.uid() and status = 'pending');
create policy "admin manages bookings" on public.venue_bookings for update to authenticated
using (public.is_admin()) with check (public.is_admin());

-- Note: production registration, ticket issuance, capacity checks, and QR check-in
-- should be implemented with transaction-safe RPC/server functions before public launch.
