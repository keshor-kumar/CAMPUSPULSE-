# Deploy CampusPulse (about 5 minutes)

## 1. Database (Supabase)
1. Create a project at supabase.com.
2. SQL Editor → paste and run **`supabase/all_in_one.sql`** (schema + RLS + registration/check-in/approval functions + seed events, venues, 23 map locations).
3. Authentication → Sign up with `sr8658@srmist.edu.in` (or Auth → Users → Add user, auto-confirm), then run **`supabase/make_admin.sql`**.
4. Authentication → URL Configuration → add your site URL (and `http://localhost:5173`) to Site URL / Redirect URLs.
5. Project Settings → API → copy the **Project URL** and the **anon / publishable key**.

## 2. Website (Vercel — or Netlify)
1. Import the GitHub repo in Vercel (framework: Vite, auto-detected; `vercel.json` handles SPA routing).
2. Add environment variables: `VITE_SUPABASE_URL`, `VITE_SUPABASE_ANON_KEY`.
3. Deploy. Netlify works the same way (`netlify.toml` included).

CLI alternative: `npm i -g vercel && vercel --prod` (then add the two env vars in the dashboard and redeploy).

Never put the service-role key in any `VITE_` variable.

## Android app (APK)

The repo includes a GitHub Actions workflow (`.github/workflows/android-apk.yml`) that wraps the site with Capacitor and builds a debug APK.

1. Push to GitHub, open **Actions → Build Android APK → Run workflow** (it also runs on every push to `main`).
2. After about 6–10 minutes, download `CampusPulse.apk` from **Releases → CampusPulse APK** (or the run's Artifacts).
3. On the phone: open the file and allow "Install unknown apps" when asked.
4. For live data, add repo secrets `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` before running. Without them the app runs in browser-only demo mode.

The site is also installable from Chrome on Android (menu → Install app) because it ships a web manifest.
