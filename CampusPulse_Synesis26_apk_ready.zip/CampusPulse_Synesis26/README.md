# CampusPulse — Synesis 26

**Your Campus. Your Community. One Pulse.**

A React + TypeScript + Vite starter for the CampusPulse college campus platform, designed around SRM Ramapuram.

## What's included

- Responsive landing page with polished event cards and search/category filters.
- Student sign-in and registration UI.
- Separate admin sign-in entry point.
- Supabase Auth integration scaffold.
- Role-based dashboard routing after successful Supabase login.
- Student and admin dashboard layouts.
- Campus blueprint viewer with 23 searchable/selectable location markers.
- Community Zone feature previews.
- Supabase SQL schema and initial RLS policies.
- `.env.example` with placeholders only.

## Status

The frontend is wired to Supabase: live events (with registration counts), capacity-safe registration, tickets and check-in, student event proposals, admin approvals, announcements, admin stats and the campus-locations table. **See [DEPLOY.md](DEPLOY.md) for the 5-minute database + Vercel setup** (`supabase/all_in_one.sql` creates everything, including seed data). Without Supabase credentials the site still runs in a read-only demo mode with sample events.

Not yet built: AI poster extraction, payments, community messaging, clubs/lost-and-found/venue-booking UIs (tables exist), and an automated test suite.

## Requirements

- Node.js 20 or later recommended.
- npm.
- A Supabase project for real authentication and persistent data.

## Run locally

```bash
npm install
npm run dev
```

Open the local URL printed by Vite, usually `http://localhost:5173`.

## Configure Supabase

1. Create a Supabase project.
2. Copy `.env.example` to `.env`.
3. Set `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` (the project publishable/anon key).
4. In the Supabase SQL Editor, review and apply `supabase/migrations/001_initial_schema.sql`.
5. In Authentication settings, configure allowed redirect URLs and email verification/password reset settings.
6. Restart Vite after changing `.env`.

Never put a Supabase service-role key, AI API key, or password in Vite environment variables. Variables prefixed with `VITE_` are public to the browser.

## Initialize the first administrator

New signups are assigned the `student` role by the database trigger. Do not add a public admin registration flow.

Create the account for `sr8658@srmist.edu.in` using the Supabase Auth dashboard or a trusted server-side provisioning process. Then, using a trusted administrator-only SQL session (not the public app), verify the email and assign the role to the correct auth user UUID:

```sql
-- Replace the UUID with the verified auth.users.id for the intended admin.
update public.profiles
set role = 'admin'
where id = 'REPLACE-WITH-VERIFIED-USER-UUID'
  and exists (
    select 1 from auth.users
    where auth.users.id = public.profiles.id
      and lower(auth.users.email) = 'sr8658@srmist.edu.in'
  );
```

Use the initial password supplied by the project owner only during secure provisioning, then change it immediately. Never commit or share it. Do not run the example query until you have verified the target UUID and email in the Supabase dashboard.

## Build and preview

```bash
npm run build
npm run preview
```

## Campus map

The supplied blueprint is stored at `public/images/srm-ramapuram-campus-map.png`. Marker positions are approximate percentages in `src/data/locations.ts` and should be visually checked against the source image. This is a static blueprint, not GPS/indoor navigation.

## Known limitations

- Main event cards currently use clearly separated sample data in `src/data/events.ts`.
- Event registration persistence, transactional capacity control, ticket issuance, QR scanner backend validation, and attendance RPC are not yet complete.
- Admin dashboard statistics shown in the prototype are illustrative, not real database counts.
- Poster extraction needs a configured server-side AI/OCR integration.
- Community, announcements, clubs, lost-and-found, venue booking, and analytics pages need their complete database-backed workflows implemented.
- The initial SQL schema is a starting point; review policies and add transaction-safe functions, tests, and storage policies before production use.
- The application has not been penetration-tested or fully end-to-end tested against a configured Supabase project.

## Deployment

Deploy the frontend to Vercel, set the same public Supabase environment variables in Vercel project settings, and add the production domain to Supabase Auth redirect/allowed URL settings. Run the production build before deployment.

## Feature status

- [x] Responsive landing page and visual design
- [x] Sample event search and category filters
- [x] Student registration/login UI with Supabase Auth calls
- [x] Admin login entry and role check
- [x] Student/admin dashboard shell
- [x] Campus map with 23 selectable approximate markers
- [x] Initial database schema and baseline RLS policies
- [ ] Complete production event CRUD and approval workflow
- [ ] Transaction-safe event registration and capacity checks
- [ ] QR ticket issuance and secure check-in RPC
- [ ] AI poster extraction integration
- [ ] Complete community and messaging backend
- [ ] Complete admin CRUD and analytics
- [ ] Full integration and end-to-end test suite
